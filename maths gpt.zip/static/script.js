document.getElementById('math-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const problem = document.getElementById('problem').value;

    try {
        const response = await fetch('/solve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ problem })
        });
        const data = await response.json();

        if (data.result) {
            document.getElementById('result').textContent = `Result: ${data.result}`;
        } else {
            document.getElementById('result').textContent = `Error: ${data.error}`;
        }
    } catch (error) {
        document.getElementById('result').textContent = 'An error occurred. Please try again.';
    }
});
